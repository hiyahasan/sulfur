<?php

/**
 * Plugin Name: Sul Custom
 * Description: Sulfur Custom Post Typrs Plugin
 * Plugin URI: https://www.robiul.com
 * Author: Robiul Hasan
 * Text Domain: sul
 * 
 *
 */


 
    // Gallery Custom Post
    function sul_custom_posts(){
 
       // Team Custom Post
       register_post_type('team', array(
        'labels' => array(
            'name' => __('Teams', 'sul'),
            'singular_name' => __('Team', 'sul'),
            'add_new'   =>__('Add New Team','sul'),
            'add_new_item'   =>__('Add New Team','sul'),
            'featured_image' =>__('Add Team Image','sul'),
            'set_featured_image' =>__('Set Team Image','sul'),
            'search_items'=>__('Search Team','sul'),
            'edit_item'    =>__('Edit Team','sul'),
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-field', 'page-attributes'),
        'menu_icon'=>'dashicons-editor-justify',
       
    ));  
    
    
    
    // Team Custom Post
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => __('Portfolios', 'sul'),
            'singular_name' => __('Portfolio', 'sul'),
            'add_new'   =>__('Add New Portfolio','sul'),
            'add_new_item'   =>__('Add New Portfolio','sul'),
            'featured_image' =>__('Add Portfolio Image','sul'),
            'set_featured_image' =>__('Set Portfolio Image','sul'),
            'search_items'=>__('Search Portfolio','sul'),
            'edit_item'    =>__('Edit Portfolio','sul'),
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-field', 'page-attributes'),
        'menu_icon'=>'dashicons-editor-justify',
       
    ));
     


        //  Service section start here 
        register_post_type('service', array(
            'labels' => array(
                'name' => __('Services', 'sul'),
                'singular_name' => __('Service', 'sul'),
                'add_new'   =>__('Add New Service','sul'),
                'add_new_item'   =>__('Add New Service','sul'),
                'featured_image' =>__('Add Service Image','sul'),
                'set_featured_image' =>__('Set Service Image','sul'),
                'search_items'=>__('Search Service','sul'),
                'edit_item'    =>__('Edit Service','sul'),
            ),
            'public' => true,
            'supports' => array('title', 'editor' , 'custom-field', 'page-attributes'),
            'menu_icon'=>'dashicons-editor-justify',
           
        ));
    
    }
    add_action('init', 'sul_custom_posts');
